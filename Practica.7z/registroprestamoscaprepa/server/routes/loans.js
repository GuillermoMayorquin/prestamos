const express = require('express');
const router = express.Router();
const userController = require('../controllers/loansController');

router.get('/', userController.view);
router.post('/', userController.find);
router.get('/addloan', userController.form);
router.post('/addloan', userController.create);
router.get('/amortization/:id', userController.amortization);

module.exports = router;