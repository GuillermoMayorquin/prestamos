const mysql = require('mysql');

const pool = mysql.createPool({
    connectionLimit: 100,
    host           : process.env.DB_HOST,
    user           : process.env.DB_USER,
    password       : process.env.DB_PASSWORD,
    database       : process.env.DB_NAME
});


exports.view = (req, res) =>{
    pool.getConnection((err, connection) =>{
        if (err) throw err;
        console.log('Conectado con el ID ' + connection.threadId);
        connection.query('SELECT * FROM prestamosclientes', (err, rows) =>{
        connection.release();  
        
        if (!err) {
            res.render('home', {rows});
        }else{
            console.log(err);
        }

        console.log('Los datos de la tabla prestamosclientes: \n', rows);
        });
    });

};

exports.find = (req, res) =>{
    pool.getConnection((err, connection) =>{
        if (err) throw err;
        console.log('Conectado con el ID ' + connection.threadId);

        let searchTerm = req.body.search

        connection.query('SELECT * FROM prestamosclientes WHERE nombrecliente LIKE ?', ['%' + searchTerm + '%'] , (err, rows) =>{
        connection.release();  
        
        if (!err) {
            res.render('home', {rows});
        }else{
            console.log(err);
        }

        console.log('Los datos de la tabla prestamosclientes: \n', rows);
        });
    });      
};

exports.form = (req,res) =>{
    res.render('addloan');
};

exports.create = (req, res) =>{
    const {nombre_del_cliente, monto, plazos} = req.body;
    pool.getConnection((err, connection) =>{
        if (err) throw err;
        console.log('Conectado con el ID ' + connection.threadId);

        connection.query('INSERT INTO prestamosclientes(nombrecliente, monto, plazos) VALUES(?,?,?)', [nombre_del_cliente, monto, plazos] , (err, rows) =>{
        connection.release();  
        
        if (!err) {
            res.render('addloan', {alert: 'Prestamo generado exitosamente!'});
        }else{
            console.log(err);
        }
        });
    });   
};

exports.amortization = (req, res) =>{
    pool.getConnection((err, connection) =>{
        if (err) throw err;
        console.log('Conectado con el ID ' + connection.threadId);
        connection.query('SELECT * FROM prestamosclientes WHERE id = ?',[req.params.id], (err, rows) =>{
        connection.release();  
        
        if (!err) {
            res.render('amortization', {rows});
        }else{
            console.log(err);
        }

        console.log('Los datos de la tabla prestamosclientes: \n', rows);
        });
    });

};