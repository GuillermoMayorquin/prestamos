const express = require('express');
const exphbs = require ('express-handlebars');
const bodyParser = require('body-parser');
const mysql = require('mysql');

require('dotenv').config();

const app = express();
const port = process.env.PORT || 5000;


app.use(bodyParser.urlencoded({extended: false}));
app.use(bodyParser.json());
app.use(express.static('public'));



const handlebars = exphbs.create({ 
    extname: 'hbs', 
    helpers: {
      calculate:  function calculate(monto, plazos, interes, abono) {
        function round(num,dec) {
            return (Math.round(num*Math.pow(10,dec))/Math.pow(10,dec)).toFixed(dec);
        };
            quincena = interes/100;
            let pagoquincenal = monto*(quincena/12) * Math.pow((1+quincena/12),plazos)/(Math.pow((1+quincena/12),plazos)-1);
        
            let table = "";
        
            table+="<table cellpadding = '15' style='border: 1px solid black;'>";

            table+="<tr style='border: 1px solid black; text-align:center;'>";
            table+="<td style='border: 1px solid black; text-align:center;'><b>No.Pago</b></td>";
            table+="<td style='border: 1px solid black; text-align:center;'><b>Pago</b></td>";
            table+="<td style='border: 1px solid black; text-align:center;'><b>Antes de Intereses</b></td>";
            table+="<td style='border: 1px solid black; text-align:center;'><b>Intereses</b></td>";
            table+="<td style='border: 1px solid black; text-align:center;'><b>Total de Intereses Pagados</b></td>";
            table+="<td style='border: 1px solid black; text-align:center;'><b>Total Restante</b></td>";
            table+="</tr>";
            
            table+="<tr style='border: 1px solid black;'>";
                table+="<td style='border: 1px solid black; text-align:center;'>0</td>";
                table+="<td style='border: 1px solid black; text-align:center;'></td>";
                table+="<td style='border: 1px solid black; text-align:center;'></td>";
                table+="<td style='border: 1px solid black; text-align:center;'></td>";
                table+="<td style='border: 1px solid black; text-align:center;'></td>";
                table+="<td style='border: 1px solid black; text-align:center;'>"+round(monto,2)+"</td>";
            table+="</tr>";
        
        
            let current_balance = monto;
            let counter = 1;
            let total_interest = 0;
            pagoquincenal = pagoquincenal + abono;
            while (current_balance > 0) {
                towards_interest = (quincena/12) * current_balance;
        
                if (pagoquincenal > current_balance) {
                    pagoquincenal = current_balance + towards_interest;
                }
        
                towards_balance = pagoquincenal - towards_interest;
                total_interest = total_interest + towards_interest;
                current_balance = current_balance - towards_balance;
        
                table+="<tr style='border: 1px solid black; text-align:center;'>";
                table+="<td style='border: 1px solid black; text-align:center;'>"+counter+"</td>";
                table+="<td style='border: 1px solid black; text-align:center;'>"+round(pagoquincenal,2)+"</td>";
                table+="<td style='border: 1px solid black; text-align:center;'>"+round(towards_balance,2)+"</td>";
                table+="<td style='border: 1px solid black; text-align:center;'>"+round(towards_interest,2)+"</td>";
                table+="<td style='border: 1px solid black; text-align:center;'>"+round(total_interest,2)+"</td>";
                table+="<td style='border: 1px solid black; text-align:center;'>"+round(current_balance,2)+"</td>";
                table+="</tr>";
                counter++;
            };
        
            table+="</table>";

            return table;
        }
    }

});
app.set('view engine', 'hbs');
app.engine('hbs', handlebars.engine);

const pool = mysql.createPool({
    connectionLimit: 100,
    host           : process.env.DB_HOST,
    user           : process.env.DB_USER,
    password       : process.env.DB_PASSWORD,
    database       : process.env.DB_NAME
});

pool.getConnection((err, connection) =>{
    if (err) throw err;
    console.log('Conectado con el ID ' + connection.threadId);
});

const routes = require('./server/routes/loans.js');
app.use('/', routes);

app.listen(port, () => console.log(`Listening on port ${port}`));